from azure.cosmos import PartitionKey, exceptions, container, CosmosClient
from fastapi import APIRouter, Request, exceptions, Depends, HTTPException
from fastapi.encoders import jsonable_encoder

from routers.interview.requests import ScheduleReq
from .interviewModal import *
from ..authentication.userModels import *




async def schedule_interview_service(req: Request, sch_req: ScheduleReq,user:dict):
    print("bc")
    interview: Interview = Interview()

    interview.ownerEmail = user["email"]
    interview.completed = False
    interview.progress = "0.0"
    interview.start_time = sch_req.start_time
    interview.duration = sch_req.duration
    interview.end_time = sch_req.end_time
    interview.candidate_name = sch_req.candidate_name
    interview.candidate_email = sch_req.candidate_email
    interview.skills = sch_req.skills

    new_interview = await req.app.interview_items_container.create_item(interview, enable_automatic_id_generation=True)
    return new_interview["id"]
