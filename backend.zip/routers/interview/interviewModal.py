from datetime import datetime, timedelta

from pydantic import BaseModel


class Question(BaseModel):
    question: str = None
    ans: str = None
    score: int = None


class Skill(BaseModel):
    name: str
    experience: int = 1
    totalQuestions: int = 3
    questions: list[Question] = None
    score: float = 0
    feedback: str = None


class Interview(BaseModel):
    ownerEmail: str = ""
    completed: bool = False
    progress: str = "0.0"
    start_time: datetime = datetime.now()
    duration: int = 30
    end_time: datetime = datetime.now() + timedelta(minutes=duration)
    candidate_name: str
    candidate_email: str
    skills: list[Skill] = []
