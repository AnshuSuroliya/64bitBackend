from azure.cosmos import CosmosClient
from fastapi import APIRouter, Depends
from starlette.requests import Request
from dotenv import dotenv_values
from .requests import *
from .question_bank_service import *
from ..authentication.jwt_service import get_current_user

router = APIRouter()

config = dotenv_values(".env")


@router.post("/ask")
async def ask_question(reqRef: Request, req: AskQuestionReq, user: dict = Depends(get_current_user)):
    ENDPOINT = dotenv_values(".env")["db_uri"]
    KEY = dotenv_values(".env")["db_key"] + "=="

    client = CosmosClient(ENDPOINT, KEY)
    database = client.get_database_client("64bit")
    interview_container = database.get_container_client("interview")

    query = f"SELECT * FROM interview r WHERE r.id='{req.interview_id}'"
    items = list(interview_container.query_items(query, enable_cross_partition_query=True))
    interview = items[0]

    progress: str = interview["progress"].split(".")

    currentSkill = int(progress[0])
    currentQuestion = int(progress[1])

    if currentQuestion == 0:
        data = await ask_first_question(interview["candidate_name"], interview["skills"][currentSkill]["name"],
                                        interview["skills"][currentSkill]["experience"])

        if len(interview["skills"][currentSkill]["questions"]) <= currentQuestion:
            interview["skills"][currentSkill]["questions"].append({"question": data.question, "ans": "", "score": 0})
        else:
            interview["skills"][currentSkill]["questions"][currentQuestion]["question"] = data.question

        interview["progress"] = ""+str(currentSkill)+"."+str(currentQuestion+1)+""

        interview_container.replace_item(item=items[0], body=interview)

        return data
    elif currentQuestion == interview["skills"][currentSkill]["totalQuestions"]:
        lastQuestion = interview["skills"][currentSkill]["questions"][currentQuestion - 1]["question"]
        score = evaluate_question_answer(interview["skills"][currentSkill]["name"],interview["skills"][currentSkill]["experience"], lastQuestion, req.answer)
        interview["skills"][currentSkill]["questions"][currentQuestion - 1]["ans"] = req.answer
        interview["skills"][currentSkill]["questions"][currentQuestion - 1]["score"] = score

        if(len(interview["skills"])>currentSkill+1):
            interview["progress"] = "" + str(currentSkill+1) + "." + str(0) + ""

        finalSkillScore =evaluate_sKill_score(interview,currentSkill)
        interview["skills"][currentSkill]["score"] =finalSkillScore
        interview_container.replace_item(item=items[0], body=interview)

        return None

    else:
        lastQuestion = interview["skills"][currentSkill]["questions"][currentQuestion-1]["question"]
        score = evaluate_question_answer(interview["skills"][currentSkill]["name"],interview["skills"][currentSkill]["experience"],lastQuestion,req.answer)
        data = await ask_first_question(interview["candidate_name"], interview["skills"][currentSkill]["name"],interview["skills"][currentSkill]["experience"])

        if len(interview["skills"][currentSkill]["questions"]) <= currentQuestion:
            interview["skills"][currentSkill]["questions"].append({"question": data.question, "ans": "", "score": 0})
        else:
            interview["skills"][currentSkill]["questions"][currentQuestion]["question"] = data.question

        interview["skills"][currentSkill]["questions"][currentQuestion-1]["ans"]=req.answer
        interview["skills"][currentSkill]["questions"][currentQuestion-1]["score"] = score
        interview["progress"] = "" + str(currentSkill) + "." + str(currentQuestion + 1) + ""

        interview_container.replace_item(item=items[0], body=interview)
        return data


@router.get("/audio/{filename}")
async def get_audio(filename: str):
    file_path = os.path.join(".", filename)
    print(file_path)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Audio file not found")
    return FileResponse(file_path)


@router.get("/chk/IsQuestionRelevant")
async def chkquestion(req: ValidateQnReq):
    messages: list = [
        {"role": "system",
         "content": f" You are Interviewer who is interviewing for {req.skill} skill."},
        {"role": "user",
         "content": f"Check weather the question : '{req.question}' is relatable to the skill '{req.skill}' the question should also make sense to ask from an interviewee .return 'True' or 'False' depending on descision and only send 'true' and 'False' as response no extra words in response."}
    ]
    res = client.chat.completions.create(temperature=1, model=model_name, messages=messages).choices[0].message.content

    return {"isRelevant": res == "True"}
