import random

from azure.cosmos import CosmosClient

from .response import *
from dotenv import dotenv_values
from openai import AzureOpenAI
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import azure.cognitiveservices.speech as speechsdk
import os
config = dotenv_values(".env")

client = AzureOpenAI(
    api_key=config["gpt_api_key"],
    api_version=config["gpt_api_version"],
    azure_endpoint=config["gpt_azure_endpoint"]
)
model_name = "gpt-4"

speech_config = speechsdk.SpeechConfig(subscription=config["Text_to_Speech_Key"], region='eastus')
speech_config.speech_synthesis_voice_name = 'en-US-AvaNeural'
async def textToSpeech(question:str):
    print(question)
    random_number = random.randint(1,1000)
    audio_file_path = f"question_{random_number}.wav"
    audio_config = speechsdk.audio.AudioOutputConfig(filename=audio_file_path)
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    speech_synthesis_result = speech_synthesizer.speak_text_async(question).get()

    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        res=QResponse()
        res.question=question
        res.audio_url=f"/audio/question_{random_number}.wav"
        # return {"question": question, "audio_url": f"/audio/question_{random_number}.wav"}
        return res
    elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_synthesis_result.cancellation_details
        error_details = cancellation_details.error_details if cancellation_details.error_details else "No details available"
        raise HTTPException(status_code=500, detail={"reason": cancellation_details.reason, "details": error_details})


async def ask_first_question(name: str, skill: str, experience: int):
    messages: list = [
        {"role": "system",
         "content": f" You are Interviewer who is interviewing for {skill} skill for nearly {experience} years of experience. You are suppoused to ask very creative and common questions asked for that skill. also you have to evaluate the answers when asked to do so. while rating the answer you also consider is candidate is giving extra information along with bare minimum information."},
        {"role": "user",
         "content": f"Ask {name} a random question on {skill} which you haven't asked in the above conversation. and only send question as response no extra words in response."}
    ]
    res = client.chat.completions.create(temperature=1, model=model_name, messages=messages).choices[0].message.content
    messages.append({"role": "system", "content": f"{res}"})
    data = await textToSpeech(res)

    response: QuestionRes = QuestionRes()
    response.messages = messages
    response.score = []
    response.question = data.question
    response.audio_url = data.audio_url
    return response


async def in_context(messages: list, answer: str):
    messages.append({
        "role": "user",
        "content": f" check weather this answer : '{answer}' provides the answer to last question you asked.if it does provide the answer then evaluate the score the answer for last asked question from your side out of 10 then send score as INT data type  as response and if the answer is not providing the answer to question or stating sense like 'i dont know' send 'answer is not in context.' as response no extra irrelevant text."
    })
    res = client.chat.completions.create(temperature=1, model=model_name, messages=messages).choices[0].message.content
    messages.append({"role": "system", "content": res})
    return messages

def evaluate_question_answer(skill:str,exp:str, question:str , answer:str):
    messages=[{"role": "system", "content": f" You are Interviewer who is interviewing for {skill} skill in IT industry for nearly {exp} years of experience."}]
    messages.append({
        "role": "user",
        "content": f"The Question is :'{question}' \n "
                   f"The Answer is : '{answer}' \n"
                   f"Tell me how correct and relatable is the answer to the question.rate the answer out of 10 and only give a number as response no other text"
    })
    res = client.chat.completions.create(temperature=1, model=model_name, messages=messages).choices[0].message.content
    print(messages)
    print(res)

    score = int(res)
    # interview["skills"][currentSkill]["questions"][currentQuestion-1]["ans"] = answer
    # interview["skills"][currentSkill]["questions"][currentQuestion - 1]["score"] = score
    #
    # interview_container.replace_item(item=items[0],body=interview)
    # a = res.split(' ')
    # score = a[0].split('/')[0]
    # link = a[1]
    # response = EResponse()
    # response.final = "Thank you! Your Interview is now Completed,You can view your results"
    # response.score = score
    # response.link = link
    # response.skill=skill
    # return response
    return score

def evaluate_sKill_score(interview , skill_index:int):
    tot=0.0
    count = len(interview["skills"][skill_index]["questions"])
    for i in range(0, count) :
        tot =tot + int(interview["skills"][skill_index]["questions"][i]["score"])
    return tot/count
async def ask_followup_questions(messages: list, answer: str, scores:list, name:str, skill:str, experience:int):
    print(messages)
    messages = await in_context(messages,answer)
    if messages[-1]["content"] == "answer is not in context.":
        print(messages)
        que = await ask_first_question(name,skill,experience)
        return que
    messages.append({
        "role": "user",
        "content": "According to past conversations ask another followup question which is different to" +
                   "previous asked question but may related to more deeper topic from previous " +
                   "questions and answers. Only send response consisting of question no other extra " +
                   "irrelevant text other than question."
    })
    res = client.chat.completions.create(temperature=1, model=model_name, messages=messages).choices[0].message.content
    messages.append({"role": "system", "content": f"{res}"})
    data = await textToSpeech(res)
    response: QuestionRes = QuestionRes()
    response.messages = messages
    response.score = scores
    response.question = data.question
    response.audio_url = data.audio_url
    print(response)
    return response
